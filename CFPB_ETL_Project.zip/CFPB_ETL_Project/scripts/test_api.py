
import requests
import json

API_URL = (
    "https://www.consumerfinance.gov/"
    "data-research/consumer-complaints/search/api/v1/"
)

params = {
    "size": 100,
    "frm": 0,
    "date_received_min": "2023-01-01",
    "date_received_max": "2023-01-08",
    "sort": "created_date_desc",
    "no_aggs": "true",
    "no_highlight": "true"
}

print("Testing CFPB API response...")

response = requests.get(
    API_URL,
    params=params,
    timeout=120
)

response.raise_for_status()

data = response.json()

print("\n========== API RESPONSE DEBUG ==========")

print("\nTotal records:")

print(data.get("hits", {}).get("total"))

print("\nMeta information:")

meta = data.get("_meta", {})

print(json.dumps(meta, indent=4))

print("\nBreakpoints:")

breakpoints = meta.get("break_points", {})

print("Type:", type(breakpoints))

print("Available keys:", list(breakpoints.keys()))

print("\nFirst 10 breakpoints:")

for key, value in list(breakpoints.items())[:10]:
    print(f"Page {key}: {value}")

print("\nFirst record:")

hits = data.get("hits", {}).get("hits", [])

if hits:
    print(
        json.dumps(
            hits[0].get("_source", {}),
            indent=2
        )
    )

print("\n========== DEBUG COMPLETED ==========")
