
import os
import sys
import pandas as pd
import gspread

from google.oauth2.service_account import Credentials
from sqlalchemy import text

# Allow imports from project root
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_ROOT)

from config import get_database_engine


# Google Sheets Configuration
CREDENTIALS_FILE = os.path.join(
    PROJECT_ROOT,
    "credentials",
    "google_credentials.json"
)

SPREADSHEET_ID = "1qgIoxYkSea4FPmpKkCz_9NXCjO-MvQAawjc0-Wu6FxE"
WORKSHEET_NAME = "CFPB_Data"


def upload_to_google_sheets():

    print("Connecting to PostgreSQL...")

    engine = get_database_engine()

    # Change table name if your existing table has another name
    query = "SELECT * FROM consumer_complaints"

    with engine.connect() as connection:
        df = pd.read_sql(text(query), connection)

    print(f"Fetched {len(df)} records from PostgreSQL.")

    if df.empty:
        print("No records found.")
        return

    print("Connecting to Google Sheets...")

    scopes = [
        "https://www.googleapis.com/auth/spreadsheets",
        "https://www.googleapis.com/auth/drive"
    ]

    credentials = Credentials.from_service_account_file(
        CREDENTIALS_FILE,
        scopes=scopes
    )

    client = gspread.authorize(credentials)

    spreadsheet = client.open_by_key(SPREADSHEET_ID)

    # Open existing worksheet or create one
    try:
        worksheet = spreadsheet.worksheet(WORKSHEET_NAME)
    except gspread.WorksheetNotFound:
        worksheet = spreadsheet.add_worksheet(
            title=WORKSHEET_NAME,
            rows=1000,
            cols=max(len(df.columns), 1)
        )

    # Convert data to Google Sheets compatible format
    # Convert data to Google Sheets compatible format
    df = df.astype(object).where(pd.notna(df), "")

    # Convert Timestamp, date and other special values to strings
    df = df.map(
        lambda x: x.isoformat() if hasattr(x, "isoformat")
        else str(x) if not isinstance(x, (str, int, float, bool)) and x != ""
        else x
    )

    data = [df.columns.tolist()] + df.values.tolist()

    # Clear old data to avoid duplicates
    worksheet.clear()

    # Upload fresh data
    worksheet.update(
        range_name="A1",
        values=data,
        value_input_option="USER_ENTERED"
    )

    print("Successfully uploaded data to Google Sheets!")
    print(f"Total records uploaded: {len(df)}")


if __name__ == "__main__":
    upload_to_google_sheets()
